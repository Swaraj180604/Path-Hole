import numpy as np
import pandas as pd
import pytest

from core import sensor


@pytest.fixture(scope="module")
def clf():
    return sensor.train_model(duration_s=300)


def test_detects_events_on_unseen_drive(clf):
    df = sensor.make_signal(120, seed=5)
    events = sensor.detect_events(df["az"].to_numpy(), clf)
    assert len(events) > 0
    assert set(events["type"]) <= {"pothole", "speed_breaker"}
    assert events["confidence"].between(0, 1).all()


def test_flat_road_has_no_events(clf):
    rng = np.random.default_rng(0)
    az = 9.81 + rng.normal(0, 0.05, 50 * 60)
    assert len(sensor.detect_events(az, clf)) == 0


def test_too_short_recording_raises(clf):
    with pytest.raises(ValueError):
        sensor.detect_events(np.zeros(10), clf)


def test_prepare_signal_resamples_and_converts_units():
    t_ms = np.arange(0, 20_000, 10)  # 100 Hz, in milliseconds
    raw = pd.DataFrame({"time": t_ms, "az": np.ones(len(t_ms))})
    out = sensor.prepare_signal(raw, "time", "az", "milliseconds", "g")
    assert abs(out["t"].iloc[-1] - 20) < 0.1
    assert np.allclose(out["az"], sensor.G)
