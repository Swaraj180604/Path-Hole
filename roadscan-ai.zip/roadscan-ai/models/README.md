# Model weights

Put your trained YOLOv8 weights here as `models/best.pt` to enable the Camera tab
without uploading the file each time.

Train them with the notebook in `notebooks/` (Part 2). A `yolov8n` model is about
6 MB, which is fine to commit to GitHub.
