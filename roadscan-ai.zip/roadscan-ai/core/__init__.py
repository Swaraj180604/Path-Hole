"""RoadScan AI core package."""
